#pragma once

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

class inputFile
{

private :

	int newCount;
	int newCount1;
	int newFound;
	int newFound1;
	int newChoice;
	int newAmount;
	string newMember;
	string newQualifier;
	string newBufferVar;
	string newYesNo;

	vector<vector<string>>newRealVec;
	vector<vector<string>>newRealVec1;
	vector<string>newBufferVec;
	vector<string>newChanges;

public:

	inputFile();
	~inputFile();

	void memberInput(vector<string> &newBufferVec, string, int&);
	void vecInit(vector<vector<string>> &newRealVec, vector<string> newBufferVec, string, string, int&, int, int);
	void vecSort(vector<vector<string>> &newRealVec);
	void uniqueVecInit(vector<vector<string>> newRealVec, vector<vector<string>> &newRealVec1, int&);
	void vecSortLast(vector<vector<string>> &newRealVec1);
	void changesInit(vector<vector<string>> newRealVec1, vector<string> &newChanges);
	void processChoice(vector<string> newChanges, vector<vector<string>> newRealVec1, string, int, int);
	void printFullVec(vector<vector<string>> newRealVec);
	void printFrontBack(vector<vector<string>> newRealVec);
	int getVecSize(vector<vector<string>> newRealVec);

};