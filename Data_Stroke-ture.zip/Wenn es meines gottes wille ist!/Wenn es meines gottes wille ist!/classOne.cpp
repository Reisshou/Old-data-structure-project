#include "classOne.h"

inputFile::inputFile()
{
	newCount = 0;
	newFound = 0;
	newFound1 = 0;
	newChoice = 0;
	newAmount = 0;
}

inputFile::~inputFile()
{ }

void inputFile::memberInput(vector<string> &newBufferVec, string newBufferVar, int &newCount)
{
	newBufferVec.push_back(newBufferVar);
	newCount++;
}

void inputFile::vecInit(vector<vector<string>> &newRealVec, vector<string> newBufferVec, string newQualifier, string newMember, int &newCount, int newFound, int newFound1)
{
	for (int i = 0; i < newCount; i++)
	{
		vector<string> vec;
		newRealVec.push_back(vec);

		for (int j = 0; j < 7; j++)
		{
			if (j == 0)
			{
				newFound = newBufferVec[i].find(newQualifier);
				newRealVec[i].push_back(newBufferVec[i].substr(0, newFound));
			}
			else if (j > 0)
			{
				newFound = newBufferVec[i].find(";", newFound1+1);
				newRealVec[i].push_back(newBufferVec[i].substr(newFound1+1, newFound-(newFound1+1)));
			}			

			newFound1 = newFound;
		}
	}
}

void inputFile::vecSort(vector<vector<string>> &newRealVec)
{
	sort(newRealVec.begin(), newRealVec.end(), [](const vector<string>& a, const vector<string>& b)
	{
		return a[0] < b[0];
	});
}

void inputFile::uniqueVecInit(vector<vector<string>> newRealVec, vector<vector<string>> &newRealVec1, int &newCount1)
{
	for(int i = 0; i < newRealVec.size()-1; i++)
	{
		if (newRealVec[i][0] != newRealVec[i+1][0])
		{
			vector<string> vec;
			newRealVec1.push_back(vec);

			for(int j = 0; j < 7; j++)
			{
				newRealVec1[newCount1].push_back(newRealVec[i][j]);
			}

			newCount1++;

		}
	}
}

void inputFile::vecSortLast(vector<vector<string>> &newRealVec1)
{
	sort(newRealVec1.begin(), newRealVec1.end(), [](const vector<string>& a, const vector<string>& b){return a[6] < b[6];});
}

void inputFile::changesInit(vector<vector<string>> newRealVec1, vector<string> &newChanges)
{
	for (int i = 0; i < newRealVec1.size()-1; i++)
	{
		if(newRealVec1[i][6] != newRealVec1[i+1][6])
		{
			newChanges.push_back(newRealVec1[i][6]);
		}

		if(i == newRealVec1.size()-2)
		{
			newChanges.push_back(newRealVec1[i][6]);
		}
	}
}

void inputFile::processChoice(vector<string> newChanges, vector<vector<string>> newRealVec1, string newYesNo, int newChoice, int newAmount)
{
	do {
		newAmount = 0;
		cout << "\nWhich Process you want to choose to display the user ID for?\n" << endl;

		for (int i = 0; i < newChanges.size(); i++)
		{
			cout << i+1 << "." << newChanges[i] << endl;
		}

		cout << "\nEnter the Number : ";
		cin >> newChoice;

		for(int i = 0; i < newRealVec1.size(); i++)
		{
			if (newRealVec1[i].back() == newChanges[newChoice-1])
			{
				cout << newRealVec1[i].front() << " : " << newRealVec1[i].back() << endl;
				newAmount++;
			}
		}

		cout << "The amount of instances of risk assessment chosen is " << newAmount << " instances." << endl;
		cout << "Would you like to try again? (y/n)";
		cin >> newYesNo;

	} while (newYesNo == "y" || newYesNo == "Y");
}

void inputFile::printFullVec(vector<vector<string>> newRealVec)
{
	for (int i = 0; i < newRealVec.size(); i++)
	{
		for (int j = 0; j < 7; j++)
		{
			cout << newRealVec[i][j] << " : ";
		}

		cout << endl;
	}
}

void inputFile::printFrontBack(vector<vector<string>> newRealVec)
{
	for (int i = 0; i < newRealVec.size(); i++)
	{
		cout << newRealVec[i].front() << " : " << newRealVec[i].back() << endl;
	}
}

int inputFile::getVecSize(vector<vector<string>> newRealVec)
{
	return newRealVec.size();
}
