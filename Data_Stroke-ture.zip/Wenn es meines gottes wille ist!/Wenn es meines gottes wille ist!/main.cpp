#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include "classOne.h"

using namespace std;

int main()
{

	int define = 0, count = 0, count1 = 0, choice = 0, amount = 0;
	string bufferVar, qualifier = ";", member, yesNo;
	size_t found = 0, found1 = 0;

	vector<vector<string>> realVec;
	vector<vector<string>> realVec1;
	vector<string>bufferVec;
	vector<string>changes;

	inputFile objectOne;

	ifstream fileInput("Detail_Change.csv");

	if(!fileInput)
	{
		cerr << "No readable source available." << endl;
	}

	while(fileInput)
	{
		getline(fileInput, bufferVar);

		if(define > 0)
		{
			objectOne.memberInput(bufferVec, bufferVar, count);
		}

		define++;
	}

	objectOne.vecInit(realVec, bufferVec, qualifier, member, count, found, found1);
	objectOne.vecSort(realVec);
	objectOne.uniqueVecInit(realVec, realVec1, count1);
	objectOne.printFrontBack(realVec1);
	objectOne.vecSortLast(realVec1);
	objectOne.changesInit(realVec1, changes);
	objectOne.processChoice(changes, realVec1, yesNo, choice, amount);

	cout << "Size of previous vector was " << objectOne.getVecSize(realVec) << endl;
	cout << "Size of current vector is " << objectOne.getVecSize(realVec1) << endl;

	system("pause");

	return 0;
}